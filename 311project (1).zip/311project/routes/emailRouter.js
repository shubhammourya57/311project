const express = require('express')
const router = express.Router()
const emailController = require('../controller/emailController')

router.post('/sendOtp',emailController.sendOtp)
router.post('/verifyOTP',emailController.verifyOTP)
router.post('/list',emailController.list)
router.post('/updateList',emailController.updateList)
module.exports = router