// data.js
const data = [
    {
      id: 1,
      name: "piyush",
      status: "Active"
    },
    {
      id: 2,
      name: "rohit",
      status: "Active"
    },
    {
      id: 3,
      name: "arpit",
      status: "Active"
    },
    {
      id: 4,
      name: "dev",
      status: "Active"
    }
  ];
  
  module.exports = data;
  