
const express = require('express');
const session = require('express-session');

const app = express();

// Configure the session middleware
app.use(session({
  secret: 'fgygfhfhntrhntdtjrfyjkrkrfty', // Change this to a secure random string
  resave: false,
  saveUninitialized: true
}));


const port = 3000
const emailRouter = require('./routes/emailRouter') 
app.use(express.json());
app.use('/',emailRouter)
 
app.listen(port, () => {
  console.log(`server listening on port ${port}`)
})