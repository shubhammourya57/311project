const express = require('express')
const nodemailer = require("../config/email")
const data = require('../data.js');


exports.sendOtp = async (req, res) => {
    try {
     const email = req.body.email
     const generateOTP = () => {
        const min = 100000; 
        const max = 999999;
        return String(Math.floor(Math.random() * (max - min + 1) + min));
      };
      
      const otp = generateOTP();
      console.log('Generated OTP:', otp);
      nodemailer.sendEMail(email,otp,req)
  
      res.json({
        status: 200,
        success: true,
        message: "Otp has been sent on your email",
      });
    } catch (error) {
      console.log(error);
      return res.status(500).json({ error: "An error occurred" });
    }
  };

  const verifyOTPn = (userEnteredOTP, req) => {
    try {
      const session = req.session;
      
      const storedOTP = session.otp;
      
      return userEnteredOTP === storedOTP;
    } catch (error) {
      console.error('Error in OTP verification:', error);
      return false;
    }
  };

exports.verifyOTP = async(req,res) => {
    try {
        
        const userEnteredOTP = req.body.otp;
    console.log(userEnteredOTP,"<userEnteredOTP")
        if (verifyOTPn(userEnteredOTP, req)) {
          console.log('OTP is valid.');
         
          return res.status(200).json({ message: 'OTP is valid' });
        } else {
          console.log('OTP is invalid.');
         
          return res.status(400).json({ error: 'OTP is invalid' });
        }
      } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'An error occurred' });
      }
}  


exports.verifyOTPn = (userEnteredOTP, req) => {
    try {
      const session = req.session;
      // Retrieve the stored OTP from the session
      const storedOTP = session.otp;
      // Compare the user-entered OTP with the stored OTP
      return userEnteredOTP === storedOTP;
    } catch (error) {
      console.error('Error in OTP verification:', error);
      return false;
    }
  };


 
exports.list = (req, res) => {
  const {id,name,status} = req.body
 
  const mylist= [{
    id: 1,
    name: "piyush",
    status: "Active"
  },
  {
    id: 2,
    name: "rohit",
    status: "InActive"
  },
  {
    id: 3,
    name: "arpit",
    status: "Active"
  },
  {
    id: 4,
    name: "dev",
    status: "InActive"
  }]

  res.json(data);
 
  };
  
  
  exports.updateList = (req, res) => {
    const { id, name } = req.body;
   
    const itemToUpdate = data.find(item => item.id === id || item.name === name);
  
    if (itemToUpdate) {
     
      if (id) {
        itemToUpdate.id = id;
      }
      if (name) {
        itemToUpdate.name = name;
      }
      
      res.json({ message: 'Item updated' });
    } else {
      res.status(404).json({ error: 'Item not found' });
    }
  };
  
  
  