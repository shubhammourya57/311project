var nodemailer = require("nodemailer");
// var config = require("./config");


var EMAIL_ID = "swapinfotechindore@gmail.com";
var EMAIL_PASSWORD = "ejnljjxnhcautboc";
var transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  options: {
    debug: true,
  },
  auth: {
    user: EMAIL_ID,
    pass: EMAIL_PASSWORD,
  },
});
var sendEMail = (email,otp,req) => {
  const session = req.session;

  // Store the OTP in the session
  session.otp = otp;
  let mailOptions = {
    from:`${EMAIL_ID}`,
    to: email,
    subject: "otp",
    text:`this is otp for verification  ${otp}`
  };
  mailOptions.headers={
    "content-Type":"text\html"
  }
  return new Promise(function (resolve, reject) {
    transporter.sendMail(mailOptions, function (err, info) {
      if (err) {
        console.log(err);
        reject(err);
      } else {
        console.log(info);
        resolve(info);
      }
    });
  });
};


// const verifyOTP = (userEnteredOTP, req) => {
//   const session = req.session;

  
//   const storedOTP = session.otp;

  
//   if (userEnteredOTP === storedOTP) {
   
//     return true;
//   } else {
    
//     return false;
//   }
// };


// const userEnteredOTP = '123456'; // Replace with the user's input
// if (verifyOTP(userEnteredOTP, req)) {
//   console.log('OTP is valid.');
//   // Handle success - e.g., allow the user to proceed
// } else {
//   console.log('OTP is invalid.');
//   // Handle failure - e.g., show an error message to the user
// }




module.exports = {
  transporter,
  sendEMail,
 
};
